/*----------------------------------------------------------------------------
 * Name:    CanDemo.c
 * Purpose: CAN example for LPC23xx with MCB2300
 * Version: V1.00
 * Note(s):
 *----------------------------------------------------------------------------
 * This file is part of the uVision/ARM development tools.
 * This software may only be used under the terms of a valid, current,
 * end user licence from KEIL for a compatible version of KEIL software
 * development tools. Nothing else gives you the right to use this software.
 *
 * This software is supplied "AS IS" without warranties of any kind.
 *
 * Copyright (c) 2009-2013 Keil - An ARM Company. All rights reserved.
 *----------------------------------------------------------------------------
 * History:
 *          V1.00 Initial Version
 *----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdint.h>                             /* Include standard types */
#include <LPC23xx.H>                            /* LPC17xx definitions */
#include "CAN.h"                                /* LPC1766 CAN adaption layer */
#include "LCD.h"                                /* LCD function prototypes */
#ifdef RT_AGENT
#include "RT_Agent.h"                           /* Real-Time Agent definitions */
#endif

unsigned char order[32] = {'\0'};
int len,send_data_flag;
unsigned char val_Rx;
/*----------------------------------------------------------------------------
  insert a delay time.
 *----------------------------------------------------------------------------*/
void delay(unsigned int nCount)	{
  for(; nCount != 0; nCount--);
}

/*----------------------------------------------------------------------------
  UART1 init
 *----------------------------------------------------------------------------*/
void uart_init()
{
	PINSEL0 &= ~0xC0000000;
	PINSEL0 |=  0x40000000;
	PINSEL1 &= ~0x00000003;
	PINSEL1 |=  0x00000001;
	U1FCR = 0x07;																// Enable FIFO and reset tx and rx buffers
	U1LCR = 0x83;																// Enable DLAB, no parity, 1 stop bit, 8-bit word length
	
	U1DLM = 0;
	U1DLL = 0x4e;																// Baud rate is 9600
	
	U1LCR = 0x03;
}

/*----------------------------------------------------------------------------
  display transmit and receieve values
 *---------------------------------------------------------------------------*/
void val_display (void) {
	char buff[16];
	sprintf(buff,"rx:%c len:%d",val_Rx,len);
  lcd_clear();
	set_cursor (0, 1);
  lcd_print  ((char*)buff);                  
  delay (1000000);                                /* Wait wait a while */
}

/*----------------------------------------------------------------------------
 *       sendchar:  Write a character to Serial Port
 *---------------------------------------------------------------------------*/
int sendchar (int ch) {
  if (ch == '\n') {
    while (!(U1LSR & 0x20));
    U1THR = '\r';
  }
  while (!(U1LSR & 0x20));
  return (U1THR = ch);
}

/*----------------------------------------------------------------------------
  Send data via uart
 *---------------------------------------------------------------------------*/
void send_data_uart (void) {
int j=0;
while(j<len)
{
sendchar(order[j]);
j=j+1;
}
}


/*----------------------------------------------------------------------------
  initialize CAN interface
 *----------------------------------------------------------------------------*/
void can_Init (void) {

  CAN_setup (1);                                  /* setup CAN Controller #1 */
  CAN_setup (2);                                  /* setup CAN Controller #2 */
  CAN_wrFilter (1, 33, STANDARD_FORMAT);          /* Enable reception of messages */

  CAN_start (1);                                  /* start CAN Controller #2 */
  CAN_start (2);                                  /* start CAN Controller #2 */

  CAN_waitReady (1);                              /* wait til tx mbx is empty */
  CAN_waitReady (2);                              /* wait til tx mbx is empty */
}


/*----------------------------------------------------------------------------
  MAIN function
 *----------------------------------------------------------------------------*/
int main (void)  {
  int i = 0;
	len   = 0;
	send_data_flag =0;
#ifdef RT_AGENT
  RTA_Init();                                     /* Initialize Real-Time Agent  */
#endif
  PINSEL10 = 0;                                   /* Disable ETM interface, enable LEDs  */
  can_Init ();                                    /* initialise CAN interface */
  lcd_init();                                     /* Initialize the LCD */
	uart_init();                                  /* Initialize the UART1 */
  
	lcd_clear();                                    /* Clear the LCD */
  lcd_print ("Kitchen:"); 				                /* Display string on LCD display */
  delay (1000000);                                /* Wait wait a while */
  
while (1) {
if (CAN_RxRdy[0]) 
{                          
			FIO2PIN = ~FIO2PIN;
			//delay (1000);
			CAN_RxRdy[0] = 0;
			val_Rx = CAN_RxMsg[0].data[0];
			
if(val_Rx == '-')
			{ 
				order[i] = val_Rx;
				len=len+1;
				send_data_flag =1;														
      }
			
else
		{
			len=len+1;
			order[i] = val_Rx;
			i = i+1;
		}
val_display();
}

else if(send_data_flag)
{
	send_data_uart();
	sendchar('\n');
	send_data_flag=0;
	for(i=0;i<31;i++)
		order[i]=0;
	i=0;
	len=0;
}

  }
}
