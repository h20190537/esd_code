#include <stdint.h>                             /* Include standard types */
#include <stdio.h>
#include <LPC23xx.H>                            /* LPC17xx definitions */
#include "CAN.h"                                /* LPC1766 CAN adaption layer */
#include "LCD.h"                                /* LCD function prototypes */
#include "LED.h"                                /* LED function prototypes */
#include "ADC.h"                                /* ADC function prototypes */
#ifdef RT_AGENT
#include "RT_Agent.h"                           /* Real-Time Agent definitions */
#endif
/* Globals VAriables*/
char order_Tx[32] = {'\0'};           
char keypad[4][3] = {{'1', '2', '3'},
                     {'4', '5', '6'},
                     {'7', '8', '9'},
                     {'y', '0', 'n'}};
int col,row,key_update,order_index,send_data,get_order_flag;
char key;
          
/*----------------------------------------------------------------------------
  Variables initialization function.
 *----------------------------------------------------------------------------*/
void initialize_variables(void){
int j;
lcd_clear();
lcd_print("variables");
order_index = 0;
key_update = 0;
for (j = 0; j < 32; j++)
 order_Tx[j] = '\0';
}
          
/*----------------------------------------------------------------------------
  Keys detection function.
 *----------------------------------------------------------------------------*/
void key_press(void)
{
  FIO2PIN = (FIO2PIN & 0xFFFFFE03) | 0x000001C0;
  while ((FIO2PIN & 0x000001FC) == 0x000001C0 ){}
  if( (FIO2PIN & 0x000001C0) != 0x000001C0 )
  {
    col = FIO2PIN & 0x00001C0; 
    FIO2PIN = (FIO2PIN & 0xFFFFFE03) | 0x000001F8;     
    if ((FIO2PIN & 0x000001C0) != 0x000001C0 )
    { row = 0;
    }
     
    FIO2PIN = (FIO2PIN & 0xFFFFFE03) | 0x000001F4;
    if ((FIO2PIN & 0x000001C0) != 0x000001C0 )
    {  row = 1;
    }
     
     FIO2PIN = (FIO2PIN & 0xFFFFFE03) | 0x000001EC;
    if ((FIO2PIN & 0x000001C0) != 0x000001C0 )
    { row = 2;
    }
    FIO2PIN = (FIO2PIN & 0xFFFFFE03) | 0x000001DC;
    if ((FIO2PIN & 0x000001C0) != 0x000001C0 )
    {  row = 3;
    }
    if ( col == 0x00000180)
    key = keypad[row][0]; 
    
    else if (col == 0x000000C0)
    key = keypad[row][2];
    else if ( col == 0x00000140)
    key = keypad[row][1];
    key_update = 1;
       } 
}
/*----------------------------------------------------------------------------
  insert a delay time.
 *----------------------------------------------------------------------------*/
void delay(unsigned int nCount) {
  for(; nCount != 0; nCount--);
}
/*----------------------------------------------------------------------------
  Menu display function
 *----------------------------------------------------------------------------*/
void display_menu(void){
 lcd_clear();   
 lcd_print("WELCOME");
 set_cursor(0,1);
  lcd_print ("MENU:");                       
  delay (20000000);                                 
 lcd_clear();                                   
  lcd_print ("1:TEA       10");                                                      
 set_cursor(0,1);                                  
  lcd_print ("2:COFFEE    20");                       
  delay (20000000);                                 
 lcd_clear();                                   
  lcd_print ("3:JUICE     30");
 set_cursor(0,1);
  lcd_print ("4:LEMONADE  15");                       
 delay (20000000);
	lcd_clear();                                   
  lcd_print ("5:MILK SHAKE  80");
 set_cursor(0,1);
  lcd_print ("6:COLD DRINK  40");                       
 delay (20000000);
	lcd_clear();                                   
  lcd_print ("7:BIRYANI     150");
 set_cursor(0,1);
  lcd_print ("8:FISH        200");                       
 delay (20000000);
 lcd_clear();                                   
  lcd_print ("9:PANEER     150");                       
 delay (20000000);
}
/*----------------------------------------------------------------------------
  Display order summary function function
 *----------------------------------------------------------------------------*/
void display_order(void){
 int i=0 ;
 lcd_clear();
 lcd_print("Order Summary");
 delay(2000000);
 lcd_clear();
 lcd_print("Mobile No.:");
 set_cursor(0,1);
 for(i=0;i<10;i++)
 {
 delay(200000);
 lcd_putchar(order_Tx[i]);
 }
 delay(20000000);
 while(i<order_index)
 {
 lcd_clear();
 lcd_print("Dish:");
 lcd_putchar(order_Tx[i]);
 i++;
 set_cursor(0,1);
 lcd_print("Quantity:");
 lcd_putchar(order_Tx[i]);
 i++;
 delay(20000000);
 }
 lcd_clear();
 lcd_print("Y:Confirm");
 set_cursor(0,1);
 lcd_print("N:Cancel");
 key_press();
 while(!key_update){};
 key_update = 0;
 delay(8000000);
 if (key == 'y')
		send_data=1;
 else
		send_data=0;
}
/*----------------------------------------------------------------------------
  Get mobile number function
 *----------------------------------------------------------------------------*/
void get_mob_num(void){
 lcd_clear();                                   
 lcd_print ("Number:");
 set_cursor(0,1);
 while(order_index<10){
 key_press(); 
 if(key_update == 1){
 order_Tx[order_index] = key ; 
 delay(800000);
 lcd_print(&order_Tx[order_index]); 
 key_update = 0;
 order_index = order_index+1;
 }
 delay(10000000);
 }
}
/*----------------------------------------------------------------------------
 Take order function
 *---------------------------------------------------------------------------*/
void take_order (void) {
 while(1){
 lcd_clear();
 lcd_print("Dish No.:");
 key_press();
 while(!key_update){};
  key_update = 0;
  delay(9000000);
// if(key == 'y')
//  break;
 order_Tx[order_index] = key;
 lcd_print(&order_Tx[order_index]);
 order_index = order_index+1;
 set_cursor(0,1);
 lcd_print("Qunatity:");
 key_press();
 while(!key_update){};
  key_update = 0;
  delay(9000000);
// if(key == 'y')
//  break;
 order_Tx[order_index] = key;
 lcd_print(&order_Tx[order_index]);
 order_index = order_index+1;
 delay(9000000);
 lcd_clear();
 lcd_print("Any key:resume");
 set_cursor(0,1);
 lcd_print("n:place order");
 key_press();
 while(!key_update){};
  key_update = 0;
  delay(9000000);
 if (key == 'n')
 break;
 else
  continue;
 }
}
/*----------------------------------------------------------------------------
 Get order function
 *---------------------------------------------------------------------------*/
void get_order (void) {
lcd_clear();
lcd_print("place order");
set_cursor(0,1);
lcd_print("Y:resume, N:menu");
key_press();
while(!key_update){};
key_update = 0;
delay(9000000);
if(key == 'y')
{
 get_order_flag=1;
 take_order();
}
else if(key == 'n')
{
 get_order_flag=0;	
 return;
}
else
{
get_order_flag=0;	
lcd_clear();
lcd_print("ERROR");
delay(10000000);
}
}
/*----------------------------------------------------------------------------
  display transmit and receieve values
 *---------------------------------------------------------------------------*/
void val_display (void) {
 int i = 0;
 lcd_clear();
 while(order_Tx[i]!= '\0'){  
  lcd_print(&order_Tx[i]);
  i=i+1;
  }
  delay (1000000);                                /* Wait wait a while */
}

/*----------------------------------------------------------------------------
  initialize CAN interface
 *----------------------------------------------------------------------------*/
void can_Init (void) {
  CAN_setup (1);                                  /* setup CAN Controller #1 */
  CAN_setup (2);                                  /* setup CAN Controller #2 */
  CAN_wrFilter (1, 33, STANDARD_FORMAT);          /* Enable reception of messages */
  CAN_start (1);                                  /* start CAN Controller #2 */
  CAN_start (2);                                  /* start CAN Controller #2 */
  CAN_waitReady (1);                              /* wait til tx mbx is empty */
  CAN_waitReady (2);                              /* wait til tx mbx is empty */
}

/*----------------------------------------------------------------------------
  MAIN function
 *----------------------------------------------------------------------------*/
int main (void)  {
 int i;
 char buff[16];
 
#ifdef RT_AGENT
  RTA_Init();                                    
#endif
  PINSEL10 = 0;                                  
 FIO2DIR  = 0x0000003C;
 
 //Initialize all the modules                                  
  can_Init ();                                   
  lcd_init();                                    
  lcd_clear();                                   
  lcd_print ("HILL Restaurant");    
  delay (10000000);                              
 
	//initialize CAN message packet
  CAN_TxMsg[1].id = 33;                          
  for (i = 0; i < 8; i++) CAN_TxMsg[1].data[i] = 0;
  CAN_TxMsg[1].len = 1;
  CAN_TxMsg[1].format = STANDARD_FORMAT;
  CAN_TxMsg[1].type = DATA_FRAME;
 
 //Keep on looping for receiving the orders
 while (1) {
 send_data=0;
 initialize_variables();
 display_menu();
 get_mob_num();
 get_order();
 if(get_order_flag){
	get_order_flag=0;
	display_order();
	}
 else
	 continue;
 
 if(send_data){ 
	i=0;
	send_data = 0;
	lcd_clear();
	lcd_print("Placing Order");
	delay(2000000);
	order_Tx[order_index] = '-';
	
while(1)
	{
		if (CAN_TxRdy[1]) {                           
      CAN_TxRdy[1] = 0;
      CAN_TxMsg[1].data[0] = order_Tx[i];             
      CAN_wrMsg (2, &CAN_TxMsg[1]);  
			i++;
			delay(1000000);
	}
		if(i>order_index)
			break;
 }
	
  lcd_clear();
	lcd_print("Order Placed");
	delay(20000000);
 }
 else continue;
}
 
}
